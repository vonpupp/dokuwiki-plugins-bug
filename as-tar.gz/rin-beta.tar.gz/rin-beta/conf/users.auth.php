# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# user:MD5password:Real Name:email:groups,comma,seperated


admin:$1$$m7Bpi2IueorupAukcs.9I1:Albert De La Fuente:vonpupp@gmail.com:admin,user
