<?php
$conf['comments_allow_web']        = 0;
$conf['comments_subscription']     = 0;
$conf['comments_gravatar_rating']  = 'R';
$conf['comments_gravatar_default'] = 'blank';
$conf['comments_forbid_syntax']    = '';
$conf['comments_xhtml_renderer']   = '';
$conf['editform_set_date']         = 0;
$conf['tags']                      = '';
$conf['receive_linkbacks']         = 1;
$conf['send_linkbacks']            = 0;
