<?php

$conf['dayheaderfmt'] = '%Y-%m-%d';
$conf['maxage'] = 14*24*60*60;
