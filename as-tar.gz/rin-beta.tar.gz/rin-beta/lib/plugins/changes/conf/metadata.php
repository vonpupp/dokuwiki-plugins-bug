<?php

$meta['dayheaderfmt']       = array('string');
$meta['maxage'] = array('numeric');
