<?php

$lang['dayheaderfmt'] = 'Date format for the day headers. (strftime format)';
$lang['maxage'] = 'Oldest changes to show. 0 = disabled (in seconds)';
