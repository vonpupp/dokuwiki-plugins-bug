<?php
/**
 * Options for the Cloud Plugin
 * 
 * @author    Matthias Schulte <mailinglist@lupo49.de>
 */
$conf['minimum_word_length']          = 2;        // Minimum world length of words inside the cloud
$conf['tag_blacklist']                = '';       // Specify tags which shouldn't appear on pages

//Setup VIM: ex: et ts=2 :
