<?php
/**
 * Metadata for configuration manager plugin
 * Additions for the cloud plugin
 *
 * @author    Matthias Schulte <mailinglist@lupo49.de>
 */

$meta['minimum_word_length']    = array('numeric', '_min' => 2);
$meta['tag_blacklist']          = array('string');

//Setup VIM: ex: et ts=2 :
