<?php
/**
 * English language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Matthias Schulte <mailinglist@lupo49.de>
 */
 
// for the configuration manager
$lang['minimum_word_length']      = 'Minimum word-length for words in the cloud';
$lang['tag_blacklist']            = 'Tags, which shouldn\'t be displayed on pages (Comma seperated)';

//Setup VIM: ex: et ts=2 :
