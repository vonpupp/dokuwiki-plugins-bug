<?php
$meta['GAID'] = array('string');
$meta['dont_count_admin'] = array('onoff');
$meta['dont_count_users'] = array('onoff');
