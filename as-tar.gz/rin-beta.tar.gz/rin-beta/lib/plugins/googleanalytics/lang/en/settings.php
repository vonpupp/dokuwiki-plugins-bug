<?php
$lang['GAID'] = 'Google Analitycs ID';
$lang['dont_count_admin'] = 'Don\'t count admin/superuser';
$lang['dont_count_users'] = 'Don\'t count logged in users';
