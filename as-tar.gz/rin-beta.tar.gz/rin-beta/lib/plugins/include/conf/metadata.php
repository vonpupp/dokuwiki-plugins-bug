<?php
/**
 * Metadata for configuration manager plugin
 * Additions for the Include Plugin
 *
 * @author    Esther Brunner <wikidesign@gmail.com>
 */
$meta['firstseconly']  = array('onoff');
$meta['showtaglogos']  = array('onoff');
$meta['showfooter']    = array('onoff');
$meta['showlink']      = array('onoff');
$meta['showpermalink'] = array('onoff');
$meta['showdate']      = array('onoff');
$meta['showuser']      = array('onoff');
$meta['showcomments']  = array('onoff');
$meta['showlinkbacks'] = array('onoff');
$meta['showtags']      = array('onoff');
$meta['showeditbtn']   = array('onoff');
$meta['doredirect']    = array('onoff');
$meta['usernamespace'] = array('string');
$meta['doindent']      = array('onoff');
$meta['linkonly']      = array('onoff');
$meta['title']         = array('onoff');
$meta['pageexists']    = array('onoff');
$meta['parlink']       = array('onoff');
//Setup VIM: ex: et ts=2 :
