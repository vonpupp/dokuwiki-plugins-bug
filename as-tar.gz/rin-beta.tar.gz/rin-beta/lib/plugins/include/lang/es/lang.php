<?php
/**
 * Archivo en español
 *
 * @licencia    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @autor       Esther Brunner <wikidesign@gmail.com>
 */

// frases personalizadas en español para el plugin
$lang['readmore']   = 'Leer más...';

//Setup VIM: ex: et ts=2 :
