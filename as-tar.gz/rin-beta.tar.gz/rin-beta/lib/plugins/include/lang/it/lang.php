<?php
/**
 * Italian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Niccolo Rigacci <niccolo@rigacci.org>
 */

// custom language strings for the plugin
$lang['readmore']   = '→ Leggi tutto...';

//Setup VIM: ex: et ts=2 :
