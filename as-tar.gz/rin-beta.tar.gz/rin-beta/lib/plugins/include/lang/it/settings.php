<?php
/**
 * Italian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Niccolo Rigacci <niccolo@rigacci.org>
 */
 
// for the configuration manager
$lang['firstseconly']  = 'Mostra nel blog solo la prima sezione degli articoli';
$lang['showlink']      = 'Mostra un link all\'articolo sotto le voci del blog';
$lang['showdate']      = 'Mostra la data sotto le voci del blog';
$lang['showuser']      = 'Mostra il nome dell\'autore sotto le voci del blog';
$lang['usernamespace'] = 'Namespace per le pagine degli utenti';

//Setup VIM: ex: et ts=2 :
