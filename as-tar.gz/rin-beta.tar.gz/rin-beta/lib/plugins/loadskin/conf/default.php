<?php
/*
 * Loadskin plugin, default configuration settings
 *
 */

$conf['automaticOutput']  = 0;
$conf['excludeTemplates'] = '';
