<?php
/*
 * Loadskin plugin, configuration metadata
 *
 */

$meta['automaticOutput']  = array('onoff');
$meta['excludeTemplates'] = array('string');
