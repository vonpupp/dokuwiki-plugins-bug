<?php
/**
 * English language file for DokuWiki Plugin Loadskin
 */

$lang['template']  = 'Template';
$lang['menu']      = 'LoadSkin Template Manager';
$lang['switchTpl'] = 'Switch template';
$lang['switch']    = 'Switch';
