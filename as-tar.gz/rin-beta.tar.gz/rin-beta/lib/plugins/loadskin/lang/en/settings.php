<?php
/**
 * English language file for config
 *
 */

$lang['automaticOutput']  = 'Automatically output the template switcher on every page';
$lang['excludeTemplates'] = 'Exclude templates from template switcher (comma-separated list)';
