<?php
/**
 * Options for the Pagelist Plugin
 */
$conf['style']        = 'default';
$conf['showheader']   = 0;
$conf['showdate']     = 1;
$conf['showuser']     = 1;
$conf['showdesc']     = 0;
$conf['showcomments'] = 0;
$conf['showlinkbacks']= 0;
$conf['showtags']     = 0;
$conf['showfirsthl']  = 1;
$conf['sort']         = 0;

//Setup VIM: ex: et ts=2 :
