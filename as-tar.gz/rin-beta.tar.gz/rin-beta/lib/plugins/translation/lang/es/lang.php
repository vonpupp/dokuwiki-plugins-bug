<?php

$lang['translations'] = 'Traducciones de esta página';
