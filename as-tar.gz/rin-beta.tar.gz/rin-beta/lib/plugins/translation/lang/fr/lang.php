<?php

$lang['translations'] = 'Traductions de cette page';
