<?php
/**
 * French language file
 *
 * @author Guy Brand <gb@isis.u-strasbg.fr>
 */

$lang['translations']  = "Liste des langues disponibles séparées par des espaces (codes ISO). Ne pas inclure la langue par défaut";
$lang['translationns'] = "Si vous ne souhaitez que des traductions sous un namespace, indiquez-le ici.";
