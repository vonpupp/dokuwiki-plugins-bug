<?php

$lang['translations'] = 'Traduzioni di questa pagina';
