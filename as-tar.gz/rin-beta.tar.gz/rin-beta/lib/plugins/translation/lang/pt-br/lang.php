<?php

$lang['translations'] = 'Tradu&ccedil;&otilde;es';
