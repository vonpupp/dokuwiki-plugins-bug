<?php
/**
 * Arquivo de idioma Portugues do Brasil
 *
 * @author Paulino Michelazzo <paulino@michelazzo.com.br>
 
 * @date Oct 17, 2007
 */

$lang['translations']  = "Lista de idiomas (c&oacute;digos ISO) separada por espa&ccedil;os. N&atilde;o inclua o idioma padr&atilde;o.";
$lang['translationns'] = "Se voc&ecirc; deseja tradu&ccedil;&otilde;es somente abaixo de um determinado namespace, informe-o aqui.";
$lang['translateui']   = "A interface tamb&eacute;m deve ser alterada para o idioma selecionado pelo usu&aacute;rio?";
$lang['about']         = "Informe uma p&aacute;gina onde a funcionalidade de tradu&ccedil;&atilde;o &eacute; explicada para o usu&aacute;rio. Ela pode ser conectada com o selecionador de idiomas.";

