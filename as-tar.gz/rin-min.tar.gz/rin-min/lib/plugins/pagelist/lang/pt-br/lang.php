<?php
/**
 * Arquivo para o português
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Sidnei Neves <sidnei@sidnei.org>
 */

// cadeias customizadas da língua para o plugin
$lang['page'] = 'Página';
$lang['date'] = 'Data';
$lang['user'] = 'Usuário';
$lang['desc'] = 'Descrição';

//Setup Notepad++ enc=utf-8 :
