<?php

$lang['name']             = 'Popularity Feedback (may take some time to load)';
$lang['submit']           = 'Send Data';
$lang['autosubmit']       = 'Automatically send data once a month';
$lang['submissionFailed'] = 'The data couldn\'t be sent due to the following error:';
$lang['submitDirectly']   = 'You can send the data manually by submitting the following form.';
$lang['autosubmitError']  = 'The last autosubmit failed, because of the following error: ';
$lang['lastSent']         = 'The data has been sent ';
