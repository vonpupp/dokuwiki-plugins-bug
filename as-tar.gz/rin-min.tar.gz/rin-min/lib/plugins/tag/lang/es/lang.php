<?php
/**
 * Spanish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Digna González Otero <digna.gonzalezotero [at] gmail [dot] com>
 */
// custom language strings for the plugin
$lang['tags']  = 'Etiquetas';
$lang['topic'] = 'Tema';
 
$lang['missing_pagelistplugin'] = 'Para listas de temas debe estar instalado el Plugin Pagelist Plugin.';
 
$lang['menu'] = 'Gestor de Índice de Etiquetas';
 
//Setup VIM: ex: et ts=2 enc=utf-8 :
